package com.example.demo.entity;

import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Entity(name = "customers")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class Customers {

	@Id
	@Column(unique = true, nullable = false, precision = 10)
	int customerNumber;

	@Column(nullable = false, length = 50)
	String customerName;

	@Column(nullable = false, length = 50)
	String contactLastName;

	@Column(nullable = false, length = 50)
	String contactFirstName;

	@Column(nullable = false, length = 50)
	String phone;

	@Column(nullable = false, length = 50)
	String addressLine1;

	@Column(length = 50)
	String addressLine2;

	@Column(nullable = false, length = 50)
	String city;

	@Column(length = 50)
	String state;

	@Column(length = 15)
	String postalCode;

	@Column(nullable = false, length = 50)
	String country;

	@Column(precision = 10, scale = 2)
	BigDecimal creditLimit;

	@ManyToOne
	@JoinColumn(name = "salesRepEmployeeNumber")
	Employees employees;

	@OneToMany(mappedBy = "customer")
	@JsonManagedReference
	Set<Orders> orders;

	@OneToMany(mappedBy = "customer")
	
	Set<Payments> payments;

}
