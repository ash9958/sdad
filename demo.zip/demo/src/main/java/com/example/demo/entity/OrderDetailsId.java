package com.example.demo.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDetailsId implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Column(name = "orderNumber", nullable = false)
	@NonNull
    Integer orderNumber;

    @Column(name = "productCode", nullable = false)
    @NonNull
    String productCode;
	
}
