package com.example.demo.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Entity(name="offices")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class Offices {

    @Id
    @Column(unique=true, nullable=false, length=10)
    String officeCode;
   
    @Column(nullable=false, length=50)
    String city;
    
    @Column(nullable=false, length=50)
    String phone;
    
    @Column(nullable=false, length=50)
    String addressLine1;
    
    @Column(length=50)
    String addressLine2;
    
    @Column(length=50)
    String state;
    
    @Column(nullable=false, length=50)
    String country;
    
    @Column(nullable=false, length=15)
    String postalCode;
    
    @Column(nullable=false, length=10)
    String territory;
        

}
