package com.example.demo.controller;

import java.util.List;
//CEO of 'classic Model Cars' company wants to see:
//- Number of orders per customer, achieved by each employee
// (Employees have their own set of customers, need to show Order list with count, placed by the Customers of each employee)
//- Total Amount of order collected at 2005 by each employee

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employees;
import com.example.demo.entity.Offices;
import com.example.demo.entity.Orderdetails;
import com.example.demo.entity.Orders;
import com.example.demo.repository.OrdersRepository;
import com.example.demo.repository.OfficeRepository;
import com.example.demo.repository.OrdersDetailsRepository;

@RestController
public class TestController {

	@Autowired
	OfficeRepository officeRepository;

	@Autowired
	OrdersDetailsRepository ordersDetailsRepository;
	
	@Autowired
	OrdersRepository ordersRepository;
	@GetMapping("/test")
	public List<Offices> testApi() {
		return officeRepository.findAll();
	}
	@GetMapping("/test2")
	public List<Orderdetails> testApii()
	{
		return  ordersDetailsRepository.findAll();
	}
	@GetMapping("/test3")
	public List<Orders> tttt()
	{
		return ordersRepository.findAll();
	}

}
