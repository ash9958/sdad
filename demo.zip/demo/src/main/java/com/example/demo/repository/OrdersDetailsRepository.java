package com.example.demo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.entity.Employees;
import com.example.demo.entity.OrderDetailsId;
import com.example.demo.entity.Orderdetails;
import com.example.demo.entity.Orders;

public interface OrdersDetailsRepository extends JpaRepository<Orderdetails, OrderDetailsId> {

}
