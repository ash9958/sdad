package com.example.demo.entity;

import java.math.BigDecimal;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Entity(name="products")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class Products {
	
    @Id
    @Column(unique=true, nullable=false, length=15)
    String productCode;
   
    @Column(nullable=false, length=70)
    String productName;
    
    @Column(nullable=false, length=10)
    String productScale;
    
    @Column(nullable=false, length=50)
    String productVendor;
    
    @Column(nullable=false)
    String productDescription;
    
    @Column(nullable=false, precision=5)
    short quantityInStock;
    
    @Column(nullable=false, precision=10, scale=2)
    BigDecimal buyPrice;
    
    @Column(name="MSRP", nullable=false, precision=10, scale=2)
    BigDecimal msrp;
    
    @OneToMany(mappedBy="product")
    @JsonManagedReference
    Set<Orderdetails> orderdetail;
    
    @ManyToOne(optional=false)
    @JoinColumn(name="productLine", nullable=false)
    Productlines productline;

   
}
