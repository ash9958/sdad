package com.example.demo.entity;

import java.sql.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Entity(name = "orders")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class Orders {

	@Id
	@Column(unique = true, nullable = false, precision = 10)
	Integer orderNumber;
	
	@Column(nullable = false)
	Date orderDate;
	
	@Column(nullable = false)
	Date requiredDate;
	
	Date shippedDate;
	
	@Column(nullable = false, length = 15)
	String status;
	
	String comments;
	
	@OneToMany(mappedBy = "order")
	@JsonBackReference
	Set<Orderdetails> orderdetails;
	
	@ManyToOne(optional = false)
	@JoinColumn(name = "customerNumber", nullable = false)
	@JsonBackReference
	Customers customer;

}
