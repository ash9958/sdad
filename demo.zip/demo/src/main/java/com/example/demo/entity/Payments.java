package com.example.demo.entity;

import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Entity(name="payments")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class Payments {
	
	@Id
    @Column(nullable=false, length=50)
    String checkNumber;
    
    @Column(nullable=false)
    Date paymentDate;
    
    @Column(nullable=false, precision=10, scale=2)
    BigDecimal amount;
    
    @ManyToOne(optional=false)
    @JoinColumn(name="customerNumber", nullable=false)
    Customers customer;

}
