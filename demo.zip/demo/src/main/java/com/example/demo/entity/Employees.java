package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Entity(name="employees")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class Employees {

    @Id
    @Column(unique=true, nullable=false, precision=10)
    int employeeNumber;
    
    @Column(nullable=false, length=50)
    String lastName;
    
    @Column(nullable=false, length=50)
    String firstName;
    
    @Column(nullable=false, length=10)
    String extension;
    
    @Column(nullable=false, length=100)
    String email;
    
    @Column(nullable=false, length=50)
    String jobTitle;
    
    @ManyToOne
    @JoinColumn(name="reportsTo")
    Employees reportsTo;
    
    @ManyToOne(optional=false)
    @JoinColumn(name="officeCode", nullable=false)
    Offices office;

}
