package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.example.demo.entity.OrderDetailsId;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
//		new OrderDetailsId(orderNumber, productCode)
//		new Orderdetails
		SpringApplication.run(DemoApplication.class, args);
	}

}
