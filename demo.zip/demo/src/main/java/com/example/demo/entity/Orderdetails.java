package com.example.demo.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity(name = "orderdetails")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@NoArgsConstructor
public class Orderdetails {	
	@EmbeddedId
	OrderDetailsId id;
	
	@Column(nullable = false, precision = 10)
	int quantityOrdered;

	@Column(nullable = false, precision = 10, scale = 2)
	BigDecimal priceEach;

	@Column(nullable = false, precision = 5)
	short orderLineNumber;

	@ManyToOne(optional = false)
	@JoinColumn(name = "orderNumber", nullable = false)
	@MapsId("orderNumber")
	@JsonManagedReference
	Orders order;

	@ManyToOne(optional = false)
	@JoinColumn(name = "productCode", nullable = false)
	@MapsId("productCode")
	@JsonBackReference
	Products product;

}
