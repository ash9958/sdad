package com.example.demo.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@Entity(name = "productlines")
@Data
@FieldDefaults(level = AccessLevel.PRIVATE)
@AllArgsConstructor
@NoArgsConstructor
public class Productlines {

	@Id
	@Column(unique = true, nullable = false, length = 50)
	String productLine;
	
	@Column(length = 4000)
	String textDescription;
	
	@Column(length = 16777215)
	String htmlDescription;
	
	@Column(length = 16777215)
	byte[] image;
	
	@OneToMany(mappedBy = "productline")
	Set<Products> products;

}
